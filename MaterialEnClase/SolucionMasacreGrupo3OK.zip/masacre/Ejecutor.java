package com.masacre;

import jdk.swing.interop.SwingInterOpUtils;

public class Ejecutor {
    public static void main(String[] args) {
        // LISTA MASACRE
        FanMasacre fm1 = new FanMasacre("Josue","Almeyda","12345678",26,5,"muerte",10,4);
        FanMasacre fm2 = new FanMasacre("Andrés","Carmona","1325487",27,10,"destrucción",5,3);
        FanMasacre fm3 = new FanMasacre("Jesús","López","81726354",29,15,"nuclear",12,6);

        // LISTA TELEVIDENTE
        Televidente tlv1 = new Televidente("Luis","Huaman","77063719", 24,8,"98765421",10);
        Televidente tlv2 = new Televidente("Alonso","Córdoba","76825341", 29,7,"98765422",13);
        Televidente tlv3 = new Televidente("Elber","Nuñez","718273654", 27,6,"98765423",15);


        //1. REGISTRO DE PARTICIPANTES
        Administrador administrador = new Administrador();
        administrador.registrarParticipantes(fm1);
        administrador.registrarParticipantes(fm2);
        administrador.registrarParticipantes(fm3);
        administrador.registrarParticipantes(tlv1);
        administrador.registrarParticipantes(tlv2);
        administrador.registrarParticipantes(tlv3);

        //2. OBTENER GANADOR
        System.out.println("El concursante ganador es: "+administrador.obtenerGanador().getNombre() + " con "+ administrador.obtenerGanador().obtenerPuntaje() + " puntos. \n");

        //3. OBTENER LISTA Fan Masacre
        System.out.println("LISTA DE FAN MASACRE");
        for (Participante p:administrador.obtenerListaParticipante()){
            if (p.getClass()== FanMasacre.class) {
                System.out.println(p + " Puntaje: " + p.obtenerPuntaje());
            }
        }
        System.out.println("");
        //3. OBTENER LISTA Fan Masacre
        System.out.println("LISTA TELEVIDENTES");
        for (Participante p:administrador.obtenerListaParticipante()){
            if (p.getClass()== Televidente.class) {
                System.out.println(p + " Puntaje: " + p.obtenerPuntaje());
            }
        }


        System.out.println("\n");

        //4.  OBTENER MENSAJE MENOR DE EDAD
        FanMasacre fm4 = new FanMasacre("Jesús","López","81726354",15,15,"nuclear",12,6);
        Televidente tlv4 = new Televidente("Luis","Huaman","77063719", 17,8,"98765421",10);
        administrador.registrarParticipantes(fm4);
        administrador.registrarParticipantes(tlv4);

    }
}
