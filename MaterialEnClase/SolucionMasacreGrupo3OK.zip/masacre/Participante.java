package com.masacre;

public abstract class Participante {
    private String nombre;
    private String apellido;
    private String dni;
    private int edad;
    private int cantMensajes;

    public Participante(String nombre, String apellido, String dni, int edad, int cantMensajes) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.edad = edad;
        this.cantMensajes= cantMensajes;
    }
    public Participante() {
    }

    public boolean validarEdad(){
        if (edad>=18) {
            return true;
        } else return false;
    }

    public abstract int obtenerPuntaje();
    public abstract String obtenerTipo();

    public int getCantMensajes() {
        return cantMensajes;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Participante{ " +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", dni='" + dni + '\'' +
                ", edad=" + edad +
                ", cantMensajes=" + cantMensajes +
                ',';
    }
}
