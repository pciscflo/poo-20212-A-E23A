package com.masacre;

public class FanMasacre extends Participante{
    private String equipo;
    private int puntajeBarra;
    private int puntajeEquipo;

    public FanMasacre(String nombre, String apellido, String dni, int edad, int cantMensajes, String equipo, int puntajeBarra, int puntajeEquipo) {
        super(nombre, apellido, dni, edad, cantMensajes);
        this.equipo = equipo;
        this.puntajeBarra = puntajeBarra;
        this.puntajeEquipo = puntajeEquipo;
    }


    @Override
    public int obtenerPuntaje() {
        int puntajeObtenido = getCantMensajes()*4 + puntajeBarra + puntajeEquipo*2;
        return puntajeObtenido;
    }

    @Override
    public String obtenerTipo() {
        return "FanMasacre";
    }

    @Override
    public String toString() {
        return super.toString() +
                " equipo='" + equipo + '\'' +
                ", puntajeBarra=" + puntajeBarra +
                ", puntajeEquipo=" + puntajeEquipo + " }";
    }
}
