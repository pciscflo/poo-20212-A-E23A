package com.masacre;

import java.util.ArrayList;
import java.util.List;

public class Administrador {
    private List<Participante> participantes;

    public Administrador(){
        this.participantes = new ArrayList<>();
    }

    public void registrarParticipantes (Participante participante){
        if (participante.validarEdad()==true){
        this.participantes.add(participante);
        }
        else System.out.println("El participante "+ participante.getNombre() + " tiene que ser mayor de edad");
    }

    public List<Participante> obtenerListaParticipante(){
        return participantes;
    }

    public Participante obtenerGanador() {
        double puntaje = 0;
        Participante participante=null;
        for(Participante p:this.participantes){
        if (p.obtenerPuntaje()>puntaje){
            puntaje = p.obtenerPuntaje();
            participante= p;
        }
    }
        return participante;
    }
}

