package com.masacre;

public class Televidente extends Participante{
    private String telefono;
    private int cantLlamadas;

    public Televidente(String nombre, String apellido, String dni, int edad, int cantMensajes, String telefono, int cantLlamadas) {
        super(nombre, apellido, dni, edad, cantMensajes);
        this.telefono = telefono;
        this.cantLlamadas = cantLlamadas;
    }

    @Override
    public int obtenerPuntaje() {
        int puntajeObtenido = getCantMensajes()*4 + cantLlamadas*3;
        return puntajeObtenido;
    }

    @Override
    public String obtenerTipo() {
        return "Televidente";
    }

    @Override
    public String toString() {
        return super.toString() +
                " telefono='" + telefono + '\'' +
                ", cantLlamadas=" + cantLlamadas + " }";
    }
}
